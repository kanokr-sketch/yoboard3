
  # Yo Board Website Design

  This is a code bundle for Yo Board Website Design. The original project is available at https://www.figma.com/design/PJeUXp3awVtRHn8L2H2ooP/Yo-Board-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  