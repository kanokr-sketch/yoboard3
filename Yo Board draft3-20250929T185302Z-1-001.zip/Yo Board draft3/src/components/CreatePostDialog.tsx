import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Upload, X } from "lucide-react";
import { Category, Post, Board } from "../types";

interface CreatePostDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreatePost: (post: Omit<Post, 'id' | 'createdAt'>) => void;
  boards: Board[];
  selectedBoard?: Board;
}

export function CreatePostDialog({ isOpen, onClose, onCreatePost, boards, selectedBoard }: CreatePostDialogProps) {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    description: '',
    image: '',
    contactLink: '',
    boardId: selectedBoard?.id || (boards.length > 0 ? boards[0].id : ''),
    category: selectedBoard?.category || 'หออินเตอร์' as Category
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.author || !formData.image) return;

    onCreatePost({
      ...formData,
      position: {
        x: Math.random() * 400,
        y: Math.random() * 400
      }
    });

    setFormData({
      title: '',
      author: '',
      description: '',
      image: '',
      contactLink: '',
      boardId: selectedBoard?.id || (boards.length > 0 ? boards[0].id : ''),
      category: selectedBoard?.category || 'หออินเตอร์'
    });
    onClose();
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({ ...prev, image: event.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const sampleImages = [
    "https://images.unsplash.com/photo-1741636174546-0d8c52a5aa00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYnVsbGV0aW4lMjBib2FyZCUyMHBvc3RlcnxlbnwxfHx8fDE3NTkwODUxOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1640146459297-eb4f1b084cc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwZXZlbnQlMjBwb3N0ZXJ8ZW58MXx8fHwxNzU5MDg1MTkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1689307181078-d05d73af61ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25jZXJ0JTIwcG9zdGVyJTIwZGVzaWdufGVufDF8fHx8MTc1OTA1NDQxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            สร้างโพสต์ใหม่
            {selectedBoard && (
              <span className="text-sm font-normal text-muted-foreground ml-2">
                ใน {selectedBoard.name}
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Image Upload */}
          <div className="space-y-3">
            <Label>รูปภาพโปสเตอร์</Label>
            {formData.image ? (
              <div className="relative inline-block">
                <ImageWithFallback
                  src={formData.image}
                  alt="Preview"
                  className="w-48 h-64 object-cover rounded-lg border"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={() => setFormData(prev => ({ ...prev, image: '' }))}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="mt-4">
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <span className="text-primary hover:text-primary/80">อัปโหลดรูปภาพ</span>
                      <input
                        id="image-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                      />
                    </label>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-muted-foreground mb-2">หรือเลือกจากตัวอย่าง:</p>
                  <div className="grid grid-cols-3 gap-2">
                    {sampleImages.map((url, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, image: url }))}
                        className="hover:opacity-80 transition-opacity"
                      >
                        <ImageWithFallback
                          src={url}
                          alt={`Sample ${index + 1}`}
                          className="w-full h-24 object-cover rounded border"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">ชื่อโพสต์ *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="ใส่ชื่อโพสต์"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="author">ชื่อผู้โพสต์ *</Label>
              <Input
                id="author"
                value={formData.author}
                onChange={(e) => setFormData(prev => ({ ...prev, author: e.target.value }))}
                placeholder="ใส่ชื่อผู้โพสต์"
                required
              />
            </div>
          </div>

          {/* Board Selection - only show when not in a specific board */}
          {!selectedBoard ? (
            <div className="space-y-2">
              <Label htmlFor="board">บอร์ด</Label>
              <Select 
                value={formData.boardId} 
                onValueChange={(value: string) => {
                  const board = boards.find(b => b.id === value);
                  if (board) {
                    setFormData(prev => ({ ...prev, boardId: value, category: board.category }));
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {boards.map((board) => (
                    <SelectItem key={board.id} value={board.id}>
                      {board.name} ({board.category})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>บอร์ด</Label>
              <div className="p-3 bg-muted rounded-md border">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>{selectedBoard.name}</span>
                  <span className="text-sm text-muted-foreground">({selectedBoard.category})</span>
                </div>
                {selectedBoard.description && (
                  <p className="text-sm text-muted-foreground mt-1">{selectedBoard.description}</p>
                )}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">รายละเอียด</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="ใส่รายละเอียดโพสต์"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact">ช่องทางการติดต่อ</Label>
            <Input
              id="contact"
              value={formData.contactLink}
              onChange={(e) => setFormData(prev => ({ ...prev, contactLink: e.target.value }))}
              placeholder="เช่น https://line.me/..., tel:0812345678, https://instagram.com/..."
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose}>
              ยกเลิก
            </Button>
            <Button type="submit" disabled={!formData.title || !formData.author || !formData.image}>
              สร้างโพสต์
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}