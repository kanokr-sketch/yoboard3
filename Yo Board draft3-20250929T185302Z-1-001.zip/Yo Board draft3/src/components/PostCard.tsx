import { useDrag } from 'react-dnd';
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Card } from "./ui/card";
import { Post } from '../types';
import { motion } from 'motion/react';
import { Clock, User, Tag } from 'lucide-react';

interface PostCardProps {
  post: Post;
  onPostClick: (post: Post) => void;
  onPositionChange: (id: string, position: { x: number; y: number }) => void;
}

export function PostCard({ post, onPostClick, onPositionChange }: PostCardProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'post',
    item: { id: post.id, currentPosition: post.position },
    end: (item, monitor) => {
      const dropResult = monitor.getDropResult();
      if (item && dropResult) {
        onPositionChange(item.id, dropResult.position);
      }
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  // Get category color
  const getCategoryColor = (category: string) => {
    switch(category) {
      case 'หอใน': return { bg: 'bg-emerald-100', text: 'text-emerald-700', border: 'border-l-emerald-500' };
      case 'หอนอก': return { bg: 'bg-blue-100', text: 'text-blue-700', border: 'border-l-blue-500' };
      case 'คณะ': return { bg: 'bg-purple-100', text: 'text-purple-700', border: 'border-l-purple-500' };
      case 'คอมมูนิตี้': return { bg: 'bg-amber-100', text: 'text-amber-700', border: 'border-l-amber-500' };
      case 'ยิม': return { bg: 'bg-red-100', text: 'text-red-700', border: 'border-l-red-500' };
      case 'กีฬา': return { bg: 'bg-yellow-100', text: 'text-yellow-700', border: 'border-l-yellow-500' };
      case 'ร้านอาหาร': return { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-l-orange-500' };
      case 'สถานที่บรรเทิง': return { bg: 'bg-pink-100', text: 'text-pink-700', border: 'border-l-pink-500' };
      default: return { bg: 'bg-gray-100', text: 'text-gray-700', border: 'border-l-gray-500' };
    }
  };

  const categoryTheme = getCategoryColor(post.category);

  return (
    <motion.div
      ref={drag}
      className="absolute cursor-move"
      style={{
        left: post.position.x,
        top: post.position.y,
        zIndex: isDragging ? 1000 : 1,
      }}
      animate={{
        opacity: isDragging ? 0.7 : 1,
        rotate: isDragging ? 8 : 0,
        scale: isDragging ? 1.05 : 1,
      }}
      whileHover={{ 
        scale: 1.03,
        rotate: 2,
        y: -5
      }}
      transition={{ 
        type: "spring", 
        stiffness: 300, 
        damping: 20 
      }}
    >
      <Card 
        className={`w-52 bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-2xl transition-all duration-300 border-l-4 ${categoryTheme.border} overflow-hidden group`}
        onClick={() => onPostClick(post)}
      >
        <div className="relative">
          {/* Category badge overlay */}
          <div className={`absolute top-2 right-2 z-10 ${categoryTheme.bg} ${categoryTheme.text} px-2 py-1 rounded-full text-xs font-medium shadow-md`}>
            <Tag className="w-3 h-3 inline mr-1" />
            {post.category}
          </div>
          
          <div className="p-3">
            <div className="relative overflow-hidden rounded-lg mb-3">
              <ImageWithFallback
                src={post.image}
                alt={post.title}
                className="w-full h-36 object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            
            <div className="space-y-2">
              <h4 className="font-bold text-sm leading-tight text-gray-800 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                {post.title}
              </h4>
              
              <div className="flex items-center gap-1 text-xs text-gray-600">
                <User className="w-3 h-3" />
                <span>โดย {post.author}</span>
              </div>
              
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{post.createdAt.toLocaleDateString('th-TH')}</span>
                </div>
                
                <motion.div 
                  className="text-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  ✨
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}