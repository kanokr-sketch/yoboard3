import { useDrop } from 'react-dnd';
import { Plus, Sparkles, Users, GraduationCap, Building2 } from "lucide-react";
import { Button } from "./ui/button";
import { PostCard } from "./PostCard";
import { Post, Category, Board } from '../types';
import { motion } from 'motion/react';

interface MainBoardProps {
  posts: Post[];
  boards: Board[];
  selectedBoard: Board | null;
  onOpenCreatePost: () => void;
  onPostClick: (post: Post) => void;
  onPostPositionChange: (id: string, position: { x: number; y: number }) => void;
}

export function MainBoard({ 
  posts, 
  boards,
  selectedBoard, 
  onOpenCreatePost, 
  onPostClick,
  onPostPositionChange 
}: MainBoardProps) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'post',
    drop: (item: any, monitor) => {
      const offset = monitor.getClientOffset();
      const boardElement = document.getElementById('main-board');
      if (offset && boardElement) {
        const boardRect = boardElement.getBoundingClientRect();
        const newPosition = {
          x: Math.max(0, Math.min(offset.x - boardRect.left - 96, boardRect.width - 192)), // 96 = half card width, 192 = card width
          y: Math.max(0, Math.min(offset.y - boardRect.top - 100, boardRect.height - 200)) // 100 = half card height, 200 = card height
        };
        return { position: newPosition };
      }
      return {};
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }));

  // Filter posts based on selected board
  const filteredPosts = selectedBoard 
    ? posts.filter(post => post.boardId === selectedBoard.id)
    : posts;

  // Get board theme colors and icons
  const getBoardTheme = (category?: Category) => {
    switch(category) {
      case 'หอใน':
        return { color: 'emerald', bg: 'from-emerald-100 via-green-50 to-teal-100', accent: '#10b981', icon: Building2 };
      case 'หออินเตอร์':
        return { color: 'blue', bg: 'from-blue-100 via-indigo-50 to-cyan-100', accent: '#3b82f6', icon: Users };
      case 'คณะ':
        return { color: 'purple', bg: 'from-purple-100 via-violet-50 to-fuchsia-100', accent: '#8b5cf6', icon: GraduationCap };
      case 'คอมมูนิตี้':
        return { color: 'amber', bg: 'from-amber-100 via-yellow-50 to-orange-100', accent: '#f59e0b', icon: Sparkles };
      default:
        return { color: 'indigo', bg: 'from-indigo-100 via-purple-50 to-pink-100', accent: '#6366f1', icon: Sparkles };
    }
  };

  const theme = getBoardTheme(selectedBoard?.category);
  const ThemeIcon = theme.icon;

  return (
    <motion.div 
      ref={drop}
      id="main-board"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={`relative w-full h-full min-h-[600px] bg-gradient-to-br ${theme.bg} border-2 border-dashed transition-all duration-300 rounded-xl overflow-hidden ${
        isOver ? `border-[${theme.accent}] bg-opacity-20` : 'border-gray-300'
      }`}
      style={{
        backgroundImage: `
          radial-gradient(circle at 20% 20%, ${theme.accent}10 2px, transparent 2px),
          radial-gradient(circle at 80% 80%, ${theme.accent}05 2px, transparent 2px),
          linear-gradient(45deg, transparent 24%, ${theme.accent}02 25%, ${theme.accent}02 26%, transparent 27%, transparent 74%, ${theme.accent}02 75%, ${theme.accent}02 76%, transparent 77%)
        `,
        backgroundSize: '60px 60px, 40px 40px, 30px 30px',
        backgroundPosition: '0 0, 30px 30px, 15px 15px'
      }}
    >
      {/* Header */}
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="absolute top-4 left-4 right-4 flex items-center justify-between z-10"
      >
        <div className="flex items-center gap-3">
          <div 
            className="p-3 rounded-xl shadow-lg"
            style={{ backgroundColor: `${theme.accent}15`, border: `2px solid ${theme.accent}30` }}
          >
            <ThemeIcon 
              className="w-6 h-6" 
              style={{ color: theme.accent }}
            />
          </div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
              {selectedBoard ? selectedBoard.name : '🎯 กระดานทั้งหมด'}
            </h2>
            <p className="text-sm text-gray-600 flex items-center gap-2">
              <span className="flex items-center gap-1">
                📌 {filteredPosts.length} โพสต์
              </span>
              {selectedBoard?.description && (
                <>
                  <span>•</span>
                  <span>{selectedBoard.description}</span>
                </>
              )}
            </p>
          </div>
        </div>
        
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            onClick={onOpenCreatePost}
            className="shadow-lg hover:shadow-xl transition-all duration-300 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            ✨ เพิ่มโพสต์
          </Button>
        </motion.div>
      </motion.div>

      {/* Posts */}
      {filteredPosts.map((post, index) => (
        <motion.div
          key={post.id}
          initial={{ opacity: 0, y: 20, rotate: Math.random() * 10 - 5 }}
          animate={{ opacity: 1, y: 0, rotate: 0 }}
          transition={{ 
            delay: index * 0.1, 
            duration: 0.5,
            type: "spring",
            stiffness: 100 
          }}
        >
          <PostCard
            post={post}
            onPostClick={onPostClick}
            onPositionChange={onPostPositionChange}
          />
        </motion.div>
      ))}

      {/* Empty state */}
      {filteredPosts.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="text-center">
            <motion.div
              animate={{ 
                rotate: [0, 10, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }}
              className="text-8xl mb-6"
            >
              🎨
            </motion.div>
            <h3 className="text-2xl mb-3 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent font-bold">
              ยังไม่มีโพสต์ในกระดานนี้
            </h3>
            <p className="text-gray-600 mb-6 max-w-md">
              เริ่มต้นความสนุกด้วยการสร้างโพสต์แรกของคุณ ✨<br/>
              แชร์เรื่องราวน่าสนใจกับเพื่อนๆ
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                onClick={onOpenCreatePost} 
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                size="lg"
              >
                <Plus className="w-5 h-5 mr-2" />
                🚀 สร้างโพสต์แรก
              </Button>
            </motion.div>
          </div>
        </motion.div>
      )}

      {/* Drop zone indicator */}
      {isOver && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute inset-0 border-2 border-dashed rounded-lg flex items-center justify-center pointer-events-none"
          style={{ 
            backgroundColor: `${theme.accent}10`,
            borderColor: theme.accent
          }}
        >
          <motion.div 
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
            className="text-center"
          >
            <div className="text-4xl mb-2">🎯</div>
            <div 
              className="text-lg font-bold"
              style={{ color: theme.accent }}
            >
              วางโพสต์ที่นี่
            </div>
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
}