import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card } from "./ui/card";
import { Plus, Home, Building, GraduationCap, Users, Sparkles, Dumbbell, Trophy, UtensilsCrossed, Music } from "lucide-react";
import { Category, Board } from '../types';
import { motion } from 'motion/react';

interface BoardSidebarProps {
  boards: Board[];
  selectedBoard: Board | null;
  onBoardSelect: (board: Board | null) => void;
  onCreateBoard: () => void;
  searchQuery: string;
}

const categoryIcons = {
  'หอนอก': Building,
  'หอใน': Home,
  'คณะ': GraduationCap,
  'คอมมูนิตี้': Users,
  'ยิม': Dumbbell,
  'กีฬา': Trophy,
  'ร้านอาหาร': UtensilsCrossed,
  'สถานที่บรรเทิง': Music,
};

const getCategoryEmoji = (category: Category) => {
  switch(category) {
    case 'หอนอก': return '🏢';
    case 'หอใน': return '🏠';
    case 'คณะ': return '🎓';
    case 'คอมมูนิตี้': return '✨';
    case 'ยิม': return '💪';
    case 'กีฬา': return '🏆';
    case 'ร้านอาหาร': return '🍽️';
    case 'สถานที่บรรเทิง': return '🎭';
    default: return '📌';
  }
};

const categories: Category[] = ['หอนอก', 'หอใน', 'คณะ', 'คอมมูนิตี้', 'ยิม', 'กีฬา', 'ร้านอาหาร', 'สถานที่บรรเทิง'];

export function BoardSidebar({ boards, selectedBoard, onBoardSelect, onCreateBoard, searchQuery }: BoardSidebarProps) {
  const [hoveredBoard, setHoveredBoard] = useState<string | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<Category | null>(null);

  // Filter boards based on search query
  const filteredBoards = boards.filter(board => 
    !searchQuery || board.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group boards by category
  const boardsByCategory = filteredBoards.reduce((acc, board) => {
    if (!acc[board.category]) {
      acc[board.category] = [];
    }
    acc[board.category].push(board);
    return acc;
  }, {} as Record<Category, Board[]>);

  const totalPosts = boards.reduce((sum, board) => sum + board.posts.length, 0);

  return (
    <div className="w-64 bg-card border-r border-border h-full flex flex-col">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 border-b border-border bg-gradient-to-r from-indigo-50 to-purple-50"
      >
        <div className="flex items-center gap-3">
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="text-2xl"
          >
            🎯
          </motion.div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Yo Board
            </h1>
            <p className="text-sm text-muted-foreground">
              ✨ กระดานประกาศชุมชน
            </p>
          </div>
        </div>
      </motion.div>

      {/* Boards */}
      <div className="flex-1 p-4 space-y-2 overflow-y-auto">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
          บอร์ด {searchQuery && `(ค้นหา: "${searchQuery}")`}
        </h3>

        {/* All Boards */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Card 
            className={`p-3 cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
              selectedBoard === null 
                ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg border-indigo-400' 
                : 'hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 border-transparent hover:border-indigo-200'
            }`}
            onClick={() => onBoardSelect(null)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div 
                  className={`p-2 rounded-lg ${selectedBoard === null ? 'bg-white/20' : 'bg-indigo-100'}`}
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <Sparkles className={`w-4 h-4 ${selectedBoard === null ? 'text-white' : 'text-indigo-600'}`} />
                </motion.div>
                <span className="font-medium">🌟 ทั้งหมด</span>
              </div>
              <Badge 
                variant={selectedBoard === null ? "secondary" : "outline"}
                className={selectedBoard === null ? "bg-white/20 text-white border-white/30" : ""}
              >
                {totalPosts}
              </Badge>
            </div>
          </Card>
        </motion.div>

        {/* Board List by Category */}
        {categories.map((category) => {
          const categoryBoards = boardsByCategory[category] || [];
          const Icon = categoryIcons[category];
          const isExpanded = expandedCategory === category;
          
          if (categoryBoards.length === 0) return null;
          
          return (
            <div key={category} className="space-y-1">
              {/* Category Header */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card
                  className="p-3 cursor-pointer transition-all duration-300 hover:shadow-md bg-gradient-to-r from-gray-50 to-gray-100 hover:from-indigo-50 hover:to-purple-50 border-l-4 border-l-indigo-400"
                  onClick={() => setExpandedCategory(isExpanded ? null : category)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <motion.div 
                        className="p-2 rounded-lg bg-indigo-100"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.5 }}
                      >
                        <Icon className="w-4 h-4 text-indigo-600" />
                      </motion.div>
                      <span className="font-medium text-gray-700">{getCategoryEmoji(category)} {category}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-indigo-100 text-indigo-700 border-indigo-300">
                        {categoryBoards.length}
                      </Badge>
                      <motion.div 
                        animate={{ rotate: isExpanded ? 90 : 0 }}
                        transition={{ duration: 0.2 }}
                        className="text-indigo-600"
                      >
                        ▶
                      </motion.div>
                    </div>
                  </div>
                </Card>
              </motion.div>

              {/* Boards in Category */}
              {isExpanded && categoryBoards.map((board, index) => {
                const isSelected = selectedBoard?.id === board.id;
                const isHovered = hoveredBoard === board.id;
                
                return (
                  <motion.div
                    key={board.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02, x: 5 }}
                  >
                    <Card
                      className={`ml-6 p-3 cursor-pointer transition-all duration-300 hover:shadow-lg border-l-2 ${
                        isSelected 
                          ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg border-l-white' 
                          : 'hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 border-l-indigo-300 hover:border-l-indigo-500'
                      }`}
                      onClick={() => onBoardSelect(board)}
                      onMouseEnter={() => setHoveredBoard(board.id)}
                      onMouseLeave={() => setHoveredBoard(null)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className={`text-sm font-medium truncate ${isSelected ? 'text-white' : 'text-gray-700'}`}>
                            {board.name}
                          </div>
                          {board.description && (
                            <div className={`text-xs truncate mt-1 ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                              {board.description}
                            </div>
                          )}
                        </div>
                        <motion.div
                          whileHover={{ scale: 1.1 }}
                          className="ml-2"
                        >
                          <Badge 
                            variant={isSelected ? "secondary" : "outline"}
                            className={`text-xs ${isSelected ? 'bg-white/20 text-white border-white/30' : 'bg-indigo-100 text-indigo-700 border-indigo-300'}`}
                          >
                            {board.posts.length}
                          </Badge>
                        </motion.div>
                      </div>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          );
        })}

        {/* No results */}
        {searchQuery && filteredBoards.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <div className="text-2xl mb-2">🔍</div>
            <p className="text-sm">ไม่พบบอร์ดที่ค้นหา</p>
            <p className="text-xs mt-1">ลองใช้คำค้นหาอื่น</p>
          </div>
        )}
      </div>

      {/* Create Board Button */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-4 border-t border-border bg-gradient-to-r from-indigo-50 to-purple-50"
      >
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button 
            onClick={onCreateBoard}
            className="w-full justify-start bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
            size="lg"
          >
            <motion.div
              whileHover={{ rotate: 180 }}
              transition={{ duration: 0.3 }}
            >
              <Plus className="w-5 h-5 mr-2" />
            </motion.div>
            🚀 สร้างบอร์ดใหม่
          </Button>
        </motion.div>
        
        <p className="text-xs text-gray-600 mt-2 text-center">
          ✨ สร้างกระดานสำหรับชุมชนของคุณ
        </p>
      </motion.div>
    </div>
  );
}