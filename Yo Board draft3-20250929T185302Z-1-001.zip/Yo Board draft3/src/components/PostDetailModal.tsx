import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ExternalLink, Calendar, User } from "lucide-react";
import { Post } from '../types';

interface PostDetailModalProps {
  post: Post | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PostDetailModal({ post, isOpen, onClose }: PostDetailModalProps) {
  if (!post) return null;

  const handleContactClick = () => {
    if (post.contactLink) {
      window.open(post.contactLink, '_blank');
    }
  };

  const getContactButtonText = (link: string) => {
    if (link.includes('line.me')) return 'ติดต่อผ่าน LINE';
    if (link.includes('instagram.com')) return 'ติดต่อผ่าน Instagram';
    if (link.includes('facebook.com')) return 'ติดต่อผ่าน Facebook';
    if (link.startsWith('tel:')) return 'โทรหา';
    if (link.includes('mailto:')) return 'ส่งอีเมล';
    return 'ติดต่อ';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span>{post.title}</span>
            <Badge variant="secondary">{post.category}</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Image */}
          <div className="flex justify-center">
            <ImageWithFallback
              src={post.image}
              alt={post.title}
              className="max-w-full h-auto max-h-96 object-contain rounded-lg border"
            />
          </div>

          {/* Details */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="w-4 h-4" />
              <span>โดย {post.author}</span>
            </div>

            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{post.createdAt.toLocaleDateString('th-TH', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}</span>
            </div>

            {post.description && (
              <div>
                <h4 className="mb-2">รายละเอียด</h4>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                  {post.description}
                </p>
              </div>
            )}

            {post.contactLink && (
              <div className="pt-4 border-t">
                <Button 
                  onClick={handleContactClick}
                  className="w-full"
                  size="lg"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  {getContactButtonText(post.contactLink)}
                </Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}