import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { motion } from 'motion/react';
import { Category, Board } from '../types';
import { Building, Home, GraduationCap, Users, Sparkles, Dumbbell, Trophy, UtensilsCrossed, Music } from 'lucide-react';

interface CreateBoardDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateBoard: (boardData: Omit<Board, 'id' | 'posts'>) => void;
}

const categoryOptions = [
  { value: 'หอนอก', label: '🏢 หอนอก', icon: Building, color: 'from-blue-500 to-cyan-500' },
  { value: 'หอใน', label: '🏠 หอใน', icon: Home, color: 'from-emerald-500 to-green-500' },
  { value: 'คณะ', label: '🎓 คณะ', icon: GraduationCap, color: 'from-purple-500 to-violet-500' },
  { value: 'คอมมูนิตี้', label: '✨ คอมมูนิตี้', icon: Users, color: 'from-amber-500 to-orange-500' },
  { value: 'ยิม', label: '💪 ยิม', icon: Dumbbell, color: 'from-red-500 to-pink-500' },
  { value: 'กีฬา', label: '🏆 กีฬา', icon: Trophy, color: 'from-yellow-500 to-amber-500' },
  { value: 'ร้านอาหาร', label: '🍽️ ร้านอาหาร', icon: UtensilsCrossed, color: 'from-orange-500 to-red-500' },
  { value: 'สถานที่บรรเทิง', label: '🎭 สถานที่บรรเทิง', icon: Music, color: 'from-pink-500 to-rose-500' },
];

export function CreateBoardDialog({ isOpen, onClose, onCreateBoard }: CreateBoardDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    category: '' as Category | '',
    description: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.category) return;

    setIsSubmitting(true);
    
    try {
      onCreateBoard({
        name: formData.name,
        category: formData.category as Category,
        description: formData.description
      });

      // Reset form
      setFormData({ name: '', category: '', description: '' });
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setFormData({ name: '', category: '', description: '' });
    onClose();
  };

  const selectedCategory = categoryOptions.find(cat => cat.value === formData.category);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-indigo-50 to-purple-50">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="text-2xl"
            >
              🎯
            </motion.div>
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              สร้างบอร์ดใหม่
            </span>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Board Name */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-gray-700">ชื่อบอร์ด</Label>
            <Input
              id="name"
              placeholder="เช่น บอร์ดหอ C, บอร์ดชุมนุมการถ่ายภาพ"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-white/70 border-indigo-200 focus:border-indigo-400"
              required
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label className="text-gray-700">หมวดหมู่</Label>
            <Select 
              value={formData.category} 
              onValueChange={(value) => setFormData({ ...formData, category: value as Category })}
            >
              <SelectTrigger className="bg-white/70 border-indigo-200 focus:border-indigo-400">
                <SelectValue placeholder="เลือกหมวดหมู่บอร์ด" />
              </SelectTrigger>
              <SelectContent>
                {categoryOptions.map((category) => {
                  const Icon = category.icon;
                  return (
                    <SelectItem key={category.value} value={category.value}>
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded bg-gradient-to-r ${category.color}`}>
                          <Icon className="w-3 h-3 text-white" />
                        </div>
                        <span>{category.label}</span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-700">คำอธิบาย (ไม่บังคับ)</Label>
            <Textarea
              id="description"
              placeholder="อธิบายเกี่ยวกับบอร์ดนี้..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="bg-white/70 border-indigo-200 focus:border-indigo-400 min-h-[80px]"
              rows={3}
            />
          </div>

          {/* Preview */}
          {formData.name && formData.category && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-lg bg-white/50 border-2 border-indigo-200"
            >
              <h4 className="text-sm font-medium text-gray-600 mb-2">ตัวอย่างบอร์ด</h4>
              <div className="flex items-center gap-3">
                {selectedCategory && (
                  <div className={`p-2 rounded-lg bg-gradient-to-r ${selectedCategory.color}`}>
                    <selectedCategory.icon className="w-4 h-4 text-white" />
                  </div>
                )}
                <div>
                  <div className="font-medium text-gray-800">{formData.name}</div>
                  {formData.description && (
                    <div className="text-sm text-gray-600">{formData.description}</div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              disabled={isSubmitting}
            >
              ยกเลิก
            </Button>
            <motion.div className="flex-1">
              <Button
                type="submit"
                disabled={!formData.name || !formData.category || isSubmitting}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                {isSubmitting ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    ⚡
                  </motion.div>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    สร้างบอร์ด
                  </>
                )}
              </Button>
            </motion.div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}